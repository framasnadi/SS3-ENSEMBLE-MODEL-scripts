# example two-dimensional profile
# (e.g. over 2 of the parameters in the low-fecundity stock-recruit function)
# remotes::install_github("r4ss/r4ss")
library(r4ss)
library(ss3diags)

base_dir <- "C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SOLE_2020/baseline_run"

dirname.profile <- paste0(base_dir,'/Profiles/sigma_steep')
dir.create(path=dirname.profile, showWarnings = TRUE, recursive = TRUE)

dir_profile_SR <- file.path(base_dir, "Profiles/sigma_steep")

# Create a subdirectory for the Plots
dirname.plotspr <- paste0(dirname.profile,"/plots_profile")
dir.create(dirname.plotspr)

# make a grid of values in both dimensions Zfrac and Beta
# vector of values to profile over
SR_sigmaR_vec <- seq(from = 0.3, to = 0.7, by = 0.1)
SR_BH_steep_vec <- seq(from = 0.7, to = , by = 0.1)
par_table <- expand.grid(SR_sigmaR = SR_sigmaR_vec, SR_BH_steep = SR_BH_steep_vec)
nrow(par_table)
## [1] 25
head(par_table)
##   Zfrac Beta
## 1   0.2 0.50
## 2   0.3 0.50
## 3   0.4 0.50
## 4   0.5 0.50
## 5   0.6 0.50
## 6   0.2 0.75

#Define the starter file

starter <- SS_readstarter(file.path(dir_profile_SR, "starter.ss"))

#Change control file name in the starter file
starter$ctlfile <- "control_modified.ss"

#Make sure the prior likelihood is calculated
#for non-estimated quantities
starter$prior_like <- 1

#Write modified starter file
SS_writestarter(starter, dir=dir_profile_SR, overwrite=TRUE)

# run SS_profile command

profile <- SS_profile(
  dir = dir_profile_SR, # directory
  masterctlfile = "control.ss",
  newctlfile = "control_modified.ss",
  string = c("SR_sigmaR","SR_BH_steep"),
  profilevec = par_table,
  extras = "-nohess"
)

# get model output
profilemodels <- SSgetoutput(dirvec=dir_profile_SR,
                             keyvec=1:nrow(par_table), getcovar=FALSE)
n <- length(profilemodels)
profilesummary <- SSsummarize(profilemodels)

# add total likelihood (row 1) to table created above
par_table$like <- as.numeric(profilesummary$likelihoods[1, 1:n])

# reshape data frame into a matrix for use with contour
like_matrix <- reshape2::acast(par_table, SR_sigmaR~SR_BH_steep, value.var="like")

# make contour plot
sspar(mfrow=c(1,1),plot.cex = 1)
contour(x = as.numeric(rownames(like_matrix)),
        y = as.numeric(colnames(like_matrix)),
        z = like_matrix, nlevels= 30,ylab="Steepness", xlab="SigmaR")
#dev.print(jpeg,"2-dimensional profile.jpg", width = 8, height = 4, res = 300, units = "in")
dev.print(jpeg,paste0(dirname.plotspr,"/2-dimensional profile.jpg"), width = 8, height = 6, res = 300, units = "in")
##############

