library(r4ss)
library(miscTools)
library(ggplot2)
library(reshape2)
library(wesanderson)
library(doParallel)
registerDoParallel(9)
#devtools::install_github('r4ss/r4ss', ref='development')

###Working directory
main.dir <- "C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove"
setwd(main.dir)

####Set the plotting directory
plotdir <- ("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/Final_Figures")
  
#To compare different models results 
# startyr = paste0(c("run13_1945","run13_1955","run13_1975" ))

Reference <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/Reference",covar=T) 

Half_indexCV <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/Half_indexCV",covar=T) 

ALK_weight <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/ALK_weight",covar=T) 

TimeVar_Lmin <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/TimeVar_Lmin",covar=T) 

CS_Sel <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/CS_Sel",covar=T) 

AgePlus8 <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/AgePlus8",covar=T) 

Acoustic <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/Acoustic",covar=T) 

CPUE <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/CPUE",covar=T) 

#Seals_2015 <- SS_output("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/Seals_2015",covar=T) 


#Create a list with all models to be compared
mymodels <- list(Reference, Half_indexCV, ALK_weight,TimeVar_Lmin,CS_Sel,AgePlus8,Acoustic,CPUE) 

#Assign the model name
modelnames <- c("Reference", "Half_indexCV", "ALK_weight", "TimeVar_Lmin", "CS_Sel", "AgePlus8",  "Acoustic", "CPUE")

#Create a summary of all models
mysummary <- SSsummarize(mymodels)    

#Plot the models
SSplotComparisons(mysummary, legendlabels=modelnames, legendloc = "topleft",  legendncol = 1, endyr=2021, print=TRUE, plotdir=plotdir, densitynames="none", xlim=c(2000,2021))

# make table of some values
mysummary <- SSsummarize(list(Reference, Half_indexCV, ALK_weight,TimeVar_Lmin,CS_Sel,AgePlus8,Acoustic,CPUE) ) 

# make table of some values
TableStatistcs <- SStableComparisons(mysummary, modelnames = modelnames, csv=TRUE, likenames = c("TOTAL", "Survey", "Length_comp","Age_comp", "priors"), names = c("Recr_Virgin", "R0", "steep", "NatM", "SSB_Virg", "SSB_2020", "F_2020", "SSB_MSY", "Fstd_MSY", "Bratio_2020", "SPRratio_2020"))
#####################################################

SS_Sensi_plot(
  model.summaries = mysummary,
  dir = plotdir,
  current.year = 2020,
  mod.names = modelnames, # List the names of the sensitivity runs
  #likelihood.out = c(1, 1, 0),
  Sensi.RE.out = "Sensi_RE_out.DMP", # Saved file of relative errors
  CI = 0.95, # Confidence interval box based on the reference model
  TRP.in = 0.4, # Target relative abundance value
  LRP.in = 0.1, # Limit relative abundance value
  sensi_xlab = "Sensitivity scenarios", # X-axis label
  ylims.in = c(-1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1), # Y-axis label
  plot.figs = c(1, 1, 1, 1, 1, 1)) # Which plots to make/save?

  #sensi.type.breaks = c(6.5, 9.5, 13.5, 16.5), # vertical breaks
  #anno.x = c(3.75, 8, 11.5, 15, 18), # positioning of types labels
  #anno.y = c(1, 1, 1, 1, 1), # positioning of types labels
  #anno.lab = c("Natural mortality", "VBGF/Mat.", "Recruitment", "Data Wts.", 
  #"Other") # Sensitivity types labels


##########################
# FINAL Kobe_plot comaprison dif runs
##########################
setwd(main.dir)  # set dir to the initial one 
runs = paste0(c("Reference", "Half_indexCV", "ALK_weight", "TimeVar_Lmin", "CS_Sel", "AgePlus8",  "Acoustic", "CPUE"))

kbproj = NULL
# Compile MVLN posteriors by scenario run
for(i in 1:length(runs)){
  # load all scenarios as list  
  run = SS_output(dir=file.path(runs[i])) 
  # get MVLN mvn.temp for each scenario
  # Make sure you set correct Fref depending on your choice
  mvn.temp = SSdeltaMVLN(run,run = runs[i],years = run$startyr:run$endyr,addprj = T,mc=5000,weight = 1,Fref = "Btgt",plot=F) #weight_vector[i]
  kbproj = rbind(kbproj,data.frame(mvn.temp$kb,model=runs[i]))
  # save labels once
  if(i==1 ) labels = mvn.temp$labels
} 
#kbproj_75 <- kbproj
#### save Ensemble r.data
save(kbproj,file="Ensemble_model_final_comp.rdata")


# Show trajectories one by one
source("C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SSplotEnsembleE.R")
sspar(mfrow=c(3,2),plot.cex = 0.9)
zoom <- c(2000,2020)
SSplotEnsemble(kbproj,quantiles = c(0.05, 0.95),add=T,legendcex = 0.5,legendloc="topleft",legendncol = 2)
dev.print(jpeg,paste0("MLVN_Compare_wVendace_Comp.jpg"), width = 12, height = 8, res = 300, units = "in")


source("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/plotkobe_fin.R")
sspar(mfrow=c(1,1),plot.cex = 0.9)
plotKobe_fin(kbproj,fill=T,joint=F,posterior="kernel",ylab="F/Ftrg",xlab="B/Btrg", legendruns = TRUE)
dev.print(jpeg,paste0("Kobe_model_FINAL_Compkernel.jpg"), width = 12, height = 8, res = 300, units = "in") 




