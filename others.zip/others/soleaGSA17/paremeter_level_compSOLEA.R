##########################
# FINAL Kobe_plot ensemble
##########################
main.dir <- "C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SOLE_2021/BENCHMARK_update" # set working directory in which you crated the runs subfolders
setwd(main.dir)
# load the ensemble .rdata (kbroj)


kbprojSelComp <- kbproj %>% mutate(run =  replace(run, run %in% c("run1_update","run2_update","run3_update","run4_update","run5_update","run6_update","run7_update","run8_update","run9_update") , "DN sel")) %>% mutate(run =  replace(run, run %in% c("run10_update","run11_update","run12_update","run13_update","run14_update","run15_update","run16_update","run17_update","run18_update") , "CS sel"))

kbprojMComp <- kbproj %>% mutate(run =  replace(run, run %in% c("run1_update","run2_update","run3_update","run10_update","run11_update","run12_update") , "M1")) %>% mutate(run =  replace(run, run %in% c("run4_update","run5_update","run6_update","run13_update","run14_update","run15_update") , "M2")) %>% mutate(run =  replace(run, run %in% c("run7_update","run8_update","run9_update","run16_update","run17_update","run18_update") , "M3"))

kbprojhComp <- kbproj %>% mutate(run =  replace(run, run %in% c("run2_update","run5_update","run8_update","run11_update","run14_update","run17_update") , "h 0.7")) %>% mutate(run =  replace(run, run %in% c("run3_update","run6_update","run9_update","run12_update","run15_update","run18_update") , "h 0.8")) %>% mutate(run =  replace(run, run %in% c("run1_update","run4_update","run7_update","run10_update","run13_update","run16_update") , "h 0.9"))

##########plot
source("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/plotkobe_fin.R")


sspar(mfrow=c(1,1),plot.cex = 0.9)
plotKobe_fin(kbprojSelComp,fill=F,joint=F,posterior="points",ylab="F/Ftrg",xlab="B/Btrg", legendruns = TRUE)
dev.print(jpeg,paste0("Kobe_final_wSOLE_selCompk.jpg"), width = 12, height = 8, res = 300, units = "in") 
sspar(mfrow=c(1,1),plot.cex = 0.9)
plotKobe_fin(kbprojMComp,fill=F,joint=F,posterior="points",ylab="F/Ftrg",xlab="B/Btrg", legendruns = TRUE)
dev.print(jpeg,paste0("Kobe_final_wSOLE_MCompk.jpg"), width = 12, height = 8, res = 300, units = "in") 
sspar(mfrow=c(1,1),plot.cex = 0.9)
plotKobe_fin(kbprojhComp,fill=F,joint=F,posterior="points",ylab="F/Ftrg",xlab="B/Btrg", legendruns = TRUE)
dev.print(jpeg,paste0("Kobe_final_wSOLE_steepCompk.jpg"), width = 12, height = 8, res = 300, units = "in") 
