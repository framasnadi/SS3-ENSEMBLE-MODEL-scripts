#########################################################################################################################
#                                                                                                                       #
#   SS3 ENSEMBLE MODEL script                                                                                           #
#   Run all scenarios at once and plot results, do diagnostic, do Ensemble on final weighted grid                       #
#                                                                                                                       #
#   September 2021                                                                                                      #
#                                                                                                                       #
#   Authors:                                                                                                            #
#   Francesco Masnadi (CNR-IRBIM & UNIBO, Ancona)                                                                       #
#   Massimiliano Cardinale (SLU Aqua, Lysekil)                                                                          #
#   mainly based on ss3diags functions developed by Hennig Winker (JRC-EC) and Felipe Carvalho (NOAA)                   #
#                                                                                                                       #
#  This script is now tailored on ensemble grid of N runs with 5 survey,15 Length data slot and 10 Age data slot.       #
#                                                                                                                       #
#  - ATTENTION: Age slot have to be activate in the Diagnostic loop before running the script (now only Length active)  #
#  - Also "sspar(mfrow=c(X,X)" in Diagnostic loop must be set accordingly                                               #
#  - Retro analysis is now set to 3 (at least 3 or 5 years)                                                             #
#  - Mohn Rho value bound set now for long-live species, please change for short-live species                           #  
#  - In Ensemble part make sure you set correct Fref depending on your choice (es. MSY,Btgt,..)                         #
#  - ATTENTION: Weighting vector automatically produce is a pure mean of all diagnostic scores as they are,             #
#    if the user want to use different Weighting methods (ex. merge multiple similar diagnostics into a single score)   #
#    have to produce the vector externally and save it in the main dir as "weight_vector.csv"                           #
#                                                                                                                       #
#                                                                                                                       #
#########################################################################################################################
library(r4ss)
library(ss3diags)
library(dplyr)
library(readr)

main.dir <- "C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SOLE_2021/BENCHMARK_update" # set working directory in which you crated the runs subfolders
 runs = paste0("run",1:18, "_update") # 1:N Number of run

###############################################################################
# Run of all grid of models together and make SS plots (Skip if already done!)
###############################################################################
  dir <- main.dir
 setwd(dir)
 for(i in 1:length(runs)){
    dir.runN <- paste0(dir,"/",runs[i])
    run_SS_models(dirvec =paste0(dir.runN), extras = "ss", skipfinished = F)
    tmp = SS_output(dir=file.path(runs[i]))
   SS_plots(tmp, uncertainty=T, datplot=F, forecast=T, maxyr=2025, minbthresh=0.25,fitrange = F)
 }
#  tmp$Dirichlet_Multinomial_pars

###########################################################
# build the empty diags table for weighting the models later
############################################################
 results <- data.frame(Run=runs, Convergence=NA, Total_LL=NA, N_Params=NA, Runs_test_SURVEY=factor(NA, levels = c("Passed","Failed")), Runs_test_lenGNS_ITA=factor(NA, levels = c("Passed","Failed")), Runs_test_lenTBB_ITA=factor(NA, levels = c("Passed","Failed")), Runs_test_lenGTR_HRV=factor(NA, levels = c("Passed","Failed")), Runs_test_lenOTB_ITA=factor(NA, levels = c("Passed","Failed")), Runs_test_lenSoleMon=factor(NA, levels = c("Passed","Failed")), RMSE_SURVEY=NA, RMSE_LEN=NA, Retro_Rho_SSB= NA, Forecast_Rho_SSB=NA, Retro_Rho_F= NA, Forecast_Rho_F=NA, MASE_SURVEY=NA, MASE_lenSURVEY=NA, MASE_COMfleet=NA)
     


##########################################################       
#*********************************************************
# Diagnostic loop
#********************************************************
########################################################## 
for(i in runs){
  # load all scenarios as list  
  dir <- main.dir
  setwd(dir)
  readme<-paste0("/",i)
  tmp <- SS_output(dir=paste0(dir,readme),covar=T,ncols=1000)
  
  ##############################
  # check for Convergence 
  ##############################
  # put in final diags table
  results$Convergence[results$Run== i] <- tmp$maximum_gradient_component
  results$Total_LL[results$Run== i] <-   tmp$likelihoods_used$values[1]
  results$N_Params[results$Run== i] <-   tmp$N_estimated_parameters
  # Par_nearBound <- as.data.frame(ifelse(tmp$parameters$Status  == "OK" | tmp$parameters$Status  == "act", 1, 0) %>% na.omit())
  
  #*********************************************************
  # Basic Residual Diagnostics (joint-residual and run test)
  #********************************************************
 # dir.create("Plotdiags",showWarnings = F) 
  dir.runN <- paste0(dir,"/",i)
  dir.diag <- paste0(dir.runN,'/Plotdiags')
  dir.create(path=dir.diag, showWarnings = T, recursive = T)
  
  # Joint-Residual (JABBAres)
  # Check conflict between indices and mean length or age
  sspar(mfrow=c(1,2),plot.cex = 0.8)   # change to 3 if also Age present
  jr.cpue <- SSplotJABBAres(tmp,subplots="cpue",add=T,col=sscol(3)[c(1,3,2)])
  jr.len <- SSplotJABBAres(tmp,subplots="len",add=T,col=sscol(3)[c(1,3,2)])
# jr.age <-SSplotJABBAres(tmp,subplots="age",add=T,col=sscol(3)[c(1,3,2)])  # activate if age data is present!
  dev.print(jpeg,paste0(dir = dir.diag,"/JointResiduals_",i,".jpg"), width = 8, height = 3.5, res = 300, units = "in")
  # put in final diags table
  results$RMSE_SURVEY[results$Run== i] <-   jr.cpue$RMSE.perc[jr.cpue$indices=="Combined"]
  results$RMSE_LEN[results$Run== i] <-   jr.len$RMSE.perc[jr.len$indices=="Combined"]
 # results$RMSE_Perc_2[results$Run== i] <-   jr.age$RMSE.perc[age.len$indices=="Combined"]
  
  # Check Runs Test 
  sspar(mfrow=c(3,2),plot.cex = 0.8)    # change based on number of fleet and length/age data
  rt.cpue <- SSplotRunstest(tmp,subplots="cpue",add=T,mixing="two.sided")
  rt.len <-SSplotRunstest(tmp,subplots="len",add=T,mixing="two.sided")
# rt.age <- SSplotRunstest(tmp,subplots="age",add=T)   # activate if age data is present!
  dev.print(jpeg,paste0(dir = dir.diag,"/RunTestResidual_",i,".jpg"), width = 8, height = 9, res = 300, units = "in")
  # put in final diags table
  #CPUE
  results$Runs_test_SURVEY[results$Run== i] <-   rt.cpue$test[1]
  # length
  results$Runs_test_lenGNS_ITA[results$Run== i] <-   rt.len$test[1]
  results$Runs_test_lenTBB_ITA[results$Run== i] <-   rt.len$test[2]
  results$Runs_test_lenGTR_HRV[results$Run== i] <-   rt.len$test[3]
  results$Runs_test_lenOTB_ITA[results$Run== i] <-   rt.len$test[4]
#  results$Runs_test_len5[results$Run== i] <-   rt.len$test[5]
  results$Runs_test_lenSoleMon[results$Run== i] <-   rt.len$test[6]


  ##############################
  # Retrospective analyses
  ##############################
  ## Automatically running the retrospective analyses
  start.retro <- 0    #end year of model
  end.retro   <- 3    #number of years for retrospective 
  # Identify the directory where a completed model run is located
  dirname.completed.model.run <- file.path(dir.runN)
  # Create a subdirectory for the Retrospectives
  dirname.Retrospective <- paste0(dir.runN,'/Retrospective')
  dir.create(path=dirname.Retrospective, showWarnings = TRUE, recursive = TRUE)
  setwd(dirname.Retrospective)
  #----------------- copy model run files ----------------------------------------
  file.copy(paste(dirname.completed.model.run,       "starter.ss_new", sep="/"),
            paste(dirname.Retrospective, "starter.ss", sep="/"))
  file.copy(paste(dirname.completed.model.run,       "control.ss_new", sep="/"),
            paste(dirname.Retrospective, "CONTROL.ss", sep="/"))
  file.copy(paste(dirname.completed.model.run,       "data.ss_new", sep="/"),
            paste(dirname.Retrospective, "DATA.ss", sep="/"))	
  file.copy(paste(dirname.completed.model.run,       "forecast.ss", sep="/"),
            paste(dirname.Retrospective, "forecast.ss", sep="/"))
  file.copy(paste(dirname.completed.model.run,       "SS.exe", sep="/"),
            paste(dirname.Retrospective, "SS.exe", sep="/"))
   file.copy(paste(dirname.completed.model.run,       "wtatage.ss", sep="/"),
            paste(dirname.Retrospective, "wtatage.ss", sep="/"))
  #------------Make Changes to the Starter.ss file (DC Example) ------------------------------- 
  starter <- readLines(paste(dirname.Retrospective, "/starter.ss", sep=""))
  # Starter File changes to speed up model runs
  # Run Display Detail
  #[8] "2 # run display detail (0,1,2)" 
  linen <- grep("# run display detail", starter)
  starter[linen] <- paste0( 1 , " # run display detail (0,1,2)" )
  write(starter, paste(dirname.Retrospective, "starter.ss", sep="/"))
  # Run the retrospective analyses with r4SS function "SS_doRetro"
  # Switch off Hessian "-nohess" (much faster)
  SS_doRetro(masterdir=dirname.Retrospective, oldsubdir="", newsubdir="", years=start.retro:-end.retro,extras="-nohess")
  # Read "SS_doRetro" output
  retroModels <- SSgetoutput(dirvec=file.path(paste0(dirname.Retrospective),paste("retro",start.retro:-end.retro,sep="")))
  # Summarize output
  retroSummary <- r4ss::SSsummarize(retroModels)
  endyrvec <- retroSummary$endyrs + start.retro:-end.retro
  sspar(mfrow=c(1,2),plot.cex = 0.8)   
  retro.ssb<- SSplotRetro(retroSummary,add=T,legendcex=0.8,tickEndYr=F,xylabs=F,legendloc = "bottomleft",uncertainty = T,showrho = T,forecast = T,labels="SSB (t)", endyrvec = c(endyrvec), subplots = c("SSB"))
    retro.f<- SSplotRetro(retroSummary,add=T,legendcex=0.8,tickEndYr=F,xylabs=F,legendloc = "bottomleft",uncertainty = T,showrho = T,forecast = T,labels="SSB (t)", endyrvec = c(endyrvec), subplots = c("F"))
  dev.print(jpeg,paste0(dir = dir.diag,"/Retro_",i,".jpg"), width = 12, height = 5, res = 300, units = "in")
   # put in final diags table
  results$Retro_Rho_SSB[results$Run== i] <-   retro.ssb$Rho[retro.ssb$peel=="Combined"]
  results$Forecast_Rho_SSB[results$Run== i] <-   retro.ssb$ForecastRho[retro.ssb$peel=="Combined"]
  results$Retro_Rho_F[results$Run== i] <-   retro.f$Rho[retro.f$peel=="Combined"]
  results$Forecast_Rho_F[results$Run== i] <-   retro.f$ForecastRho[retro.f$peel=="Combined"]

  ##############################
  # Hindcasting analyses
  ##############################
  # Do Hindcast with Cross-Validation of CPUE observations
  sspar(mfrow=c(1,1),plot.cex = 0.9)     # change based on number of cpue or survey
  mase_cpue <- SSplotHCxval(retroSummary,add=T)
  dev.print(jpeg,paste0(dir = dir.diag,"/HCxval_CPUE_",i,".jpg"), width = 8, height = 9, res = 300, units = "in")
  results$MASE_SURVEY[results$Run== i] <-   mase_cpue$MASE[1]
  # Also Hindcast with Cross-Validation for mean length or age
   # Use new converter fuction SSretroComps()
  hccomps = SSretroComps(retroModels)
  # Specify subplots = "age" or "len" in SSplotHCxval
  sspar(mfrow=c(3,2),plot.cex = 0.7) # change based on number of fleet or survey per length or age data
  mase_len.plot <- SSplotHCxval(hccomps,add=T,subplots = "len",legendloc="topright",legend = FALSE, indexUncertainty = T,legendcex = 1)
#  mase_age <- SSplotHCxval(hccomps,add=T,subplots = "age",legendloc="topright",legend = FALSE, indexUncertainty = T,legendcex = 1) # activate if age data is present!
  dev.print(jpeg,paste0(dir = dir.diag,"/HCxval_length_",i,".jpg"), width = 8, height = 9, res = 300, units = "in")
  # put in final diags table
  mase_lenSURVEY1 <- SSmase(hccomps,quants = "len", indexselect= c(6))
  mase_lenCOM <- SSmase(hccomps,quants = "len", indexselect= c(1,2,3,4))  # NO DRB
  
  results$MASE_lenSURVEY[results$Run== i] <-   mase_lenSURVEY1$MASE.adj[2]
  results$MASE_COMfleet[results$Run== i] <-   mase_lenCOM$MASE.adj[5] #take the joint MASE
}


#*********************************************************
# save the table of diagnostic with real value
#********************************************************
diags_table <- as.data.frame(t(results) %>% na.omit())
write.csv(diags_table, file = paste0(main.dir,"/Diags_table.csv"))


#*********************************************************
# save the table of diagnostic for weigthing purpose (value 0 to 1)
#********************************************************
results2 <- results %>% select(-Convergence,-Total_LL,-N_Params,-Run)

results2$Runs_test_SURVEY    <-   ifelse(results2$Runs_test_SURVEY   == 'Passed', 1, 0)
# length
results2$Runs_test_lenGNS_ITA <-   ifelse(results2$Runs_test_lenGNS_ITA == 'Passed', 1, 0)
results2$Runs_test_lenTBB_ITA <-   ifelse(results2$Runs_test_lenTBB_ITA == 'Passed', 1, 0)
results2$Runs_test_lenGTR_HRV <-   ifelse(results2$Runs_test_lenGTR_HRV == 'Passed', 1, 0)
results2$Runs_test_lenOTB_ITA <-   ifelse(results2$Runs_test_lenOTB_ITA == 'Passed', 1, 0)
results2$Runs_test_lenSoleMon <-   ifelse(results2$Runs_test_lenSoleMon == 'Passed', 1, 0)
results2$RMSE_SURVEY <- ifelse(results2$RMSE_SURVEY < 30, 1, 0)
results2$RMSE_LEN <- ifelse(results2$RMSE_LEN < 30, 1, 0)
# Age
#  results2$RMSE_Perc_2 <- ifelse(results2$RMSE_Perc_2 < 30, 1, 0)
results2$Retro_Rho_SSB <- ifelse(results2$Retro_Rho_SSB > -0.15 & results2$Retro_Rho_SSB < 0.2, 1, 0) # change to -0.22-0.30 for shorter-lived species
results2$Forecast_Rho_SSB <- ifelse(results2$Forecast_Rho_SSB > -0.15 & results2$Forecast_Rho_SSB < 0.2, 1, 0) # change to -0.22-0.30 for shorter-lived species
results2$Retro_Rho_F <- ifelse(results2$Retro_Rho_F > -0.15 & results2$Retro_Rho_F < 0.2, 1, 0) # change to -0.22-0.30 for shorter-lived species
results2$Forecast_Rho_F <- ifelse(results2$Forecast_Rho_F > -0.15 & results2$Forecast_Rho_F < 0.2, 1, 0) # change to -0.22-0.30 for shorter-lived species
results2$MASE_SURVEY <- ifelse(results2$MASE_SURVEY < 1, 1, 0)
results2$MASE_lenSURVEY <- ifelse(results2$MASE_lenSURVEY < 1, 1, 0)
results2$MASE_COMfleet <- ifelse(results2$MASE_COMfleet < 1, 1, 0)

weight_table <-  as.data.frame(t(results2) %>% na.omit())
write.csv(weight_table, file = paste0(main.dir,"/Weight_table.csv"))


####################################################
#### weight_vector to be used in Ensemble
####################################################
weight_vector <- rowMeans(as.data.frame(lapply(as.data.frame(t(weight_table)), as.numeric)))
write.csv(t(weight_vector), file = paste0(main.dir,"/weight_vector.csv"),row.names=FALSE)



#****************************************************************
# Approximate uncertainty with MVLN (hessian)
#****************************************************************
setwd(main.dir)  # set dir to the initial one 
#### weight_vector from diagnostic scores 
weight_vector <- unname(unlist(read_csv(paste0(main.dir,"/weight_vector.csv"))[1,]))
#runs = paste0("run",1:18, "_update")

kbproj = NULL
# Compile MVLN posteriors by scenario run
for(i in 1:length(runs)){
  # load all scenarios as list  
  run = SS_output(dir=file.path(runs[i])) 
  # get MVLN mvn.temp for each scenario
  # Make sure you set correct Fref depending on your choice
  mvn.temp = SSdeltaMVLN(run,run = runs[i],years = run$startyr:run$endyr,addprj = T,mc=5000,weight = weight_vector[i],Fref = "Btgt",plot=F)
  kbproj = rbind(kbproj,data.frame(mvn.temp$kb,model=runs[i]))
  # save labels once
  if(i==1 ) labels = mvn.temp$labels
} 
#### save Ensemble r.data
save(kbproj,file="Ensemble_model.rdata")

##########################
# FINAL Kobe_plot ensemble
##########################
source("C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SSplotKobeK.R")
sspar(mfrow=c(1,1),plot.cex = 0.9)
SSplotKobe(kbproj,fill=T,joint=F,posterior="kernel",ylab=labels[2],xlab=labels[1], legendpos = "bottomleft")
dev.print(jpeg,paste0("Kobe_final_wSolea.jpg"), width = 12, height = 8, res = 300, units = "in") 

# Show trajectories one by one
#source("C:/Users/f.masnadi/Desktop/Stock Assessment/SS3/SOLEA_SS3/SSplotEnsembleE.R")
sspar(mfrow=c(3,2),plot.cex = 0.9)
# zoom <- c(2010,2020)
quants = c("stock", "harvest", "SSB", "F", "Recr", "Catch")
for(i in 1:1){
  SSplotEnsemble(kbproj,quantiles = c(0.05, 0.95),add=T,subplots = quants[i],ylabs=labels[i],
                 legendcex = 0.6,legendloc = "topleft",legend=ifelse(i==1,T,T))
  abline(h= 0.5, lty = 2)
}
for(i in 2:6){
  SSplotEnsemble(kbproj,quantiles = c(0.05, 0.95),add=T,subplots = quants[i],ylabs=labels[i],
                 legendcex = 0.8,legendloc = "topleft",legend=ifelse(i==1,F,F))
}
dev.print(jpeg,paste0("MLVN_Compare.jpg"), width = 12, height = 8, res = 300, units = "in")

# timeseries
kbproj2  <- kbproj 

# Show trajectories All together 
kbproj2$run <- "All_runs"
sspar(mfrow=c(3,2),plot.cex = 0.9)
# zoom <- c(2010,2020)
quants = c("stock", "harvest", "SSB", "F", "Recr", "Catch")
for(i in 1:1){
  SSplotEnsemble(kbproj2,quantiles = c(0.05, 0.95),add=T,subplots = quants[i],ylabs=labels[i],
                 legendcex = 0.6,legendloc = "topleft",legend=ifelse(i==1,T,T))
  abline(h= 0.5, lty = 2)
}
for(i in 2:6){
  SSplotEnsemble(kbproj2,quantiles = c(0.05, 0.95),add=T,subplots = quants[i],ylabs=labels[i],
                 legendcex = 0.8,legendloc = "topleft",legend=ifelse(i==1,F,F))
}
dev.print(jpeg,paste0("MLVN_All_wSole.jpg"), width = 12, height = 8, res = 300, units = "in")



# get median + 90% CIs for SSB/SSBmsy across all models
prj_SBB_SBBtrg = aggregate(stock~year,kbproj,quantile,c(0.5,0.05,0.95))
prj_F_Btrg = aggregate(harvest~year,kbproj,quantile,c(0.5,0.05,0.95))
prj_SSB = aggregate(SSB~year,kbproj,quantile,c(0.5,0.05,0.95))
prj_F = aggregate(F~year,kbproj,quantile,c(0.5,0.05,0.95))
prj_Recr = aggregate(Recr~year,kbproj,quantile,c(0.5,0.05,0.95))
write.csv(prj_SBB_SBBtrg , "Ensemble_SBB_SBBtrg.csv")
write.csv(prj_F_Btrg , "Ensemble_F_Btrg.csv")
write.csv(prj_SSB , "Ensemble_SBB.csv")
write.csv(prj_F , "Ensemble_F.csv")
write.csv(prj_Recr , "Ensemble_Recr.csv")


##########################
# FINAL Kobe_plot comaprison dif runs
##########################
#source("C:/Users/f.masnadi/Desktop/BIOLOGIA della PESCA/DOTTORATO/overseas_SLU/VENDACE/SS3/benchmark_assessment/BASELINE_prove/plotkobe_fin.R")
#sspar(mfrow=c(1,1),plot.cex = 0.9)
#plotKobe_fin(kbproj,fill=F,joint=F,posterior="points",ylab="F/Ftrg",xlab="B/Btrg", legendruns = TRUE)
#dev.print(jpeg,paste0("Kobe_modelComp_run1weig.jpg"), width = 12, height = 8, res = 300, units = "in") 



