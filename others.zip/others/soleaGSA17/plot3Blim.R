#><>><>><>><>><>><>><>><>><>><>
#> Performance statistics
#><>><>><>><>><>><>><>><>><>><>
library(mseviz)

# Define Metrics for Evaluation
metrics <- list(SB = ssb, F = fbar, C = landings,TC=catch,Rec=rec)

Catch = list(C = list(~yearMeans(C),name="mean(C)",desc="Average Catch"))

# compute TRUE values in a list of FLPars
# Loop through stks 
rpts <- FLPars(Map(function(x,y){
  
  # Get Pars
  s= x@benchmark[["s"]]
  R0 = exp(x@benchmark[["R0"]])
  v=  x@benchmark[["B0"]]
  sr = ab(fmle(as.FLSR(x,model=bevholtSV),fixed=list(s=s,v=v,spr0=v/R0)))
  
  #><> set Blim (3 levels)
  rp= Fbrp(computeFbrp(x,sr,proxy="msy",blim=0.10))
  rp2= Fbrp(computeFbrp(x,sr,proxy="msy",blim=0.15))
  rp3= Fbrp(computeFbrp(x,sr,proxy="msy",blim=0.20))
  
  # define MSY as median yield under true Fmsy for each OM
  msy = performance(y[1], statistics=Catch,metrics=metrics, years=list(yr.eval))$data
  FLPar(
    SBmsy = rp["Btrg"], 
    Fmsy =  rp["Fbrp"], 
    Blim10 =  rp["Blim"],
    Blim15 =  rp2["Blim"],
    Blim20 =  rp3["Blim"],
    MSY =  msy,
    SB0 = rp["B0"])
},x=stks,y=runs))


# Performance Statistics
# inds2 is for plot with 3 level of blim togheter
inds2=list(
  a = list(~yearMeans(F/Fmsy),name="F/Fmsy",desc="Median annual F/Fmsy"),
  b = list(~yearMeans(SB/SBmsy),name="B/Bmsy",desc="Median annual B/Bmsy"),
  c = list(~yearMeans(C/MSY),name="Catch/MSY",desc="Mean Catch/MSY over years"),
  e1 = list(~apply(iterMeans((SB/Blim10) < 1),1,max),name="B<Blim (Blim=0.10*B0)",desc="Probability that SSB < Blim Hockey-Stick"),
  e2 = list(~apply(iterMeans((SB/Blim15) < 1),1,max),name="B<Blim (Blim=0.15*B0)",desc="Probability that SSB < Blim Hockey-Stick"), 
  e3 = list(~apply(iterMeans((SB/Blim20) < 1),1,max),name="B<Blim (Blim=0.20*B0)",desc="Probability that SSB < Blim Hockey-Stick")
)

perfrun = Map(function(x,y,z){
  pb = performance(x, refpts = y, statistics=inds2, # Now statistics, change inds to inds for blim comparison plot
                   metrics = metrics, years=list(yr.eval))
  mp = pb$mp
  pb = pb[,!"mp"]
  # Add things
  pb$run = paste0("Run",z) # allow to identify models
  pb$mp = mp # Add mp back in last column
  return(pb)
},x=runs,y=rpts,z=seq(length(rpts@names)))

# Combine in data table
perf = rbindlist(c(perfrun),idcol = "stock")
perf.tb <-  aggregate(data~mp*name,perf,quantile,c(0.5,0.05,0.95))
write.csv(perf.tb , "performance_table.csv")

###########################
## Save performance plots 
###########################
png(paste0("plots/mseperf_joint_blimcompar.png"), width = 14, height =9., res = 250, units = "in")
pbp = plotBPs(perf,c("a","b","c","e1","e2","e3"),    
              target = c(a=1,b=1,c=1),
              limit= c( e1=0.05,e2=0.05,e3=0.05,c=0.95),
              yminmax = c(0.05, 0.95))+theme_bw()+
  facet_wrap(~name,scales = "free_y",ncol=3)+
  ggtitle(paste0("Performance: All runs (3 levels of Blim)"))+
  ylab("Performance statistics")+
  theme(axis.text.x=element_blank())+xlab("Candidates")
pbp
dev.off()